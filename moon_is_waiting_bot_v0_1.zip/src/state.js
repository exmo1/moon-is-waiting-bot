import fs from "node:fs";
import path from "node:path";

const DATA_DIR = path.resolve("data");
const STATE_FILE = path.join(DATA_DIR, "state.json");

const initialState = () => ({
  users: {},
  tokens: {},
  paperPositions: {},
  seenMints: {},
  nextTokenId: 1
});

let state = initialState();

export function loadState() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  try {
    state = { ...initialState(), ...JSON.parse(fs.readFileSync(STATE_FILE, "utf8")) };
  } catch {
    state = initialState();
    saveState();
  }
  return state;
}

export function getState() { return state; }

export function saveState() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const temp = `${STATE_FILE}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(state, null, 2), { mode: 0o600 });
  fs.renameSync(temp, STATE_FILE);
}

export function getOrCreateUser(chatId, userId) {
  const key = String(chatId);
  if (!state.users[key]) {
    state.users[key] = {
      chatId: Number(chatId),
      userId: Number(userId),
      mode: "manual",
      buySol: Number(process.env.DEFAULT_BUY_SOL || 0.1),
      minScore: Number(process.env.MIN_SCORE || 90),
      takeProfitPct: 50,
      stopLossPct: 20,
      trailingStop: true,
      paused: false,
      createdAt: new Date().toISOString()
    };
    saveState();
  }
  return state.users[key];
}

export function registerToken(token) {
  if (state.seenMints[token.mint]) return null;
  const id = String(state.nextTokenId++);
  const record = { ...token, id, firstSeenAt: new Date().toISOString() };
  state.tokens[id] = record;
  state.seenMints[token.mint] = id;
  saveState();
  return record;
}

export function updateUser(chatId, patch) {
  const user = state.users[String(chatId)];
  if (!user) return null;
  Object.assign(user, patch);
  saveState();
  return user;
}

export function addPaperPosition(chatId, tokenId, amountSol, entryPrice = null) {
  const id = `${chatId}:${tokenId}:${Date.now()}`;
  state.paperPositions[id] = {
    id, chatId: Number(chatId), tokenId: String(tokenId), amountSol,
    entryPrice, status: "OPEN", openedAt: new Date().toISOString(),
    note: "Paper trade only — no blockchain transaction was sent."
  };
  saveState();
  return state.paperPositions[id];
}

export function closePaperPositions(chatId, tokenId = null) {
  const closed = [];
  for (const p of Object.values(state.paperPositions)) {
    if (p.chatId === Number(chatId) && p.status === "OPEN" && (!tokenId || p.tokenId === String(tokenId))) {
      p.status = "CLOSED";
      p.closedAt = new Date().toISOString();
      p.note = "Closed as a simulation; no real swap was executed.";
      closed.push(p);
    }
  }
  saveState();
  return closed;
}
