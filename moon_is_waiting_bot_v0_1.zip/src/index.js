import "dotenv/config";
import TelegramBot from "node-telegram-bot-api";
import { io } from "socket.io-client";
import { loadState, getState, getOrCreateUser, registerToken, updateUser, addPaperPosition, closePaperPositions, saveState } from "./state.js";
import { evaluateToken } from "./scoring.js";

const token = process.env.TELEGRAM_BOT_TOKEN;
if (!token || token === "PASTE_YOUR_TOKEN_HERE") {
  console.error("Missing TELEGRAM_BOT_TOKEN. Copy .env.example to .env and set your token privately.");
  process.exit(1);
}
if (process.env.PAPER_TRADING !== "true") {
  console.error("Safety stop: PAPER_TRADING must be true. Real swaps are not implemented in this project.");
  process.exit(1);
}

loadState();
const bot = new TelegramBot(token, { polling: true });
const shrineUrl = process.env.SHRINE_URL || "https://sol.shrine.trade";
const allowedIds = (process.env.ALLOWED_TELEGRAM_USER_IDS || "").split(",").map(x => x.trim()).filter(Boolean);

function isAllowed(msg) {
  if (!allowedIds.length) return true;
  return allowedIds.includes(String(msg.from?.id));
}
function escapeHtml(value = "") {
  return String(value).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
}
function shortAddr(value = "") {
  return value.length > 16 ? `${value.slice(0, 7)}…${value.slice(-5)}` : value || "unavailable";
}
function fmt(value) {
  return value === undefined || value === null || value === "" ? "—" : escapeHtml(value);
}
function userPositions(chatId) {
  return Object.values(getState().paperPositions).filter(p => p.chatId === Number(chatId) && p.status === "OPEN");
}
async function fetchMetadata(mint) {
  try {
    const url = new URL("/metadata", shrineUrl);
    url.searchParams.set("mint", mint);
    const response = await fetch(url, { signal: AbortSignal.timeout(4500) });
    if (!response.ok) return {};
    return await response.json();
  } catch (err) {
    console.warn("Metadata lookup failed:", err.message);
    return {};
  }
}
function extractMeta(raw) {
  // Shrine metadata fields can evolve; guard every optional field.
  const outer = raw?.metadata && typeof raw.metadata === "object" ? raw.metadata : raw;
  return {
    image: outer?.image || outer?.image_uri || outer?.imageUrl || "",
    description: outer?.description || "",
    website: outer?.website || "",
    twitter: outer?.twitter || outer?.x || "",
    telegram: outer?.telegram || ""
  };
}
function tokenMessage(t) {
  const result = evaluateToken(t);
  const score = result.score === null ? "PENDING — risk engine not validated" : `${result.score}/100`;
  const lines = [
    "🌑 <b>MOON IS WAITING — NEW TOKEN</b>",
    "",
    `🪙 <b>${escapeHtml(t.name || "Unknown token")}</b> (${escapeHtml(t.symbol || "N/A")})`,
    `📊 Alpha Score: <b>${score}</b>`,
    `🛡 Risk checks: <b>${result.eligible ? "Passed" : "Incomplete — no auto-entry"}</b>`,
    "",
    `🔗 Mint: <code>${escapeHtml(t.mint)}</code>`,
    `👤 Creator: <code>${escapeHtml(shortAddr(t.creator))}</code>`,
    `🏷 Protocol: ${escapeHtml(t.protocol || "PUMPFUN")}`,
    `🕒 Detected: ${escapeHtml(new Date((Number(t.timestamp) || Date.now() / 1000) * 1000).toLocaleString("en-GB", { timeZone: "UTC" }))} UTC`,
    "",
    "⚠️ <i>New token data is not proof of safety. Score engine is not active yet.</i>",
    "🧪 <b>Paper Trading only</b> — no real buy or sell can be executed."
  ];
  return { text: lines.join("\n"), result };
}
function tokenKeyboard(t) {
  return {
    inline_keyboard: [
      [
        { text: "🧪 Simulate BUY", callback_data: `buy:${t.id}` },
        { text: "🧪 Simulate SELL", callback_data: `sell:${t.id}` }
      ],
      [
        { text: "🔍 Analysis", callback_data: `analysis:${t.id}` },
        { text: "🔗 View on Solscan", url: `https://solscan.io/token/${encodeURIComponent(t.mint)}` }
      ],
      [
        { text: "⚙️ Settings", callback_data: "settings" }
      ]
    ]
  };
}
async function sendTokenToChat(chatId, t) {
  const msg = tokenMessage(t);
  const photo = t.image && /^https?:\/\//i.test(t.image) ? t.image : null;
  try {
    if (photo) {
      await bot.sendPhoto(chatId, photo, {
        caption: msg.text.slice(0, 1024),
        parse_mode: "HTML",
        reply_markup: tokenKeyboard(t)
      });
    } else {
      await bot.sendMessage(chatId, msg.text, {
        parse_mode: "HTML",
        reply_markup: tokenKeyboard(t),
        disable_web_page_preview: true
      });
    }
  } catch (err) {
    console.warn(`Could not alert chat ${chatId}:`, err.message);
  }
}
function settingsText(user) {
  return [
    "⚙️ <b>Your settings</b>",
    `Mode: <b>${user.mode === "auto" ? "AUTO (paper only)" : "MANUAL"}</b>`,
    `Paper buy size: <b>${user.buySol} SOL</b>`,
    `Minimum score: <b>${user.minScore}/100</b>`,
    `Take profit: <b>+${user.takeProfitPct}%</b>`,
    `Stop loss: <b>-${user.stopLossPct}%</b>`,
    `Trailing stop: <b>${user.trailingStop ? "ON" : "OFF"}</b>`,
    `New simulated entries: <b>${user.paused ? "PAUSED" : "ENABLED"}</b>`,
    "",
    "Auto mode is currently blocked until the live scoring and risk engine are implemented.",
    "No real transactions can be sent by this version."
  ].join("\n");
}
function settingsKeyboard(user) {
  return {
    inline_keyboard: [
      [
        { text: user.mode === "manual" ? "✓ Manual" : "Manual", callback_data: "mode:manual" },
        { text: user.mode === "auto" ? "✓ Auto (paper)" : "Auto (paper)", callback_data: "mode:auto" }
      ],
      [
        { text: "Buy 0.05 SOL", callback_data: "amount:0.05" },
        { text: "Buy 0.1 SOL", callback_data: "amount:0.1" },
        { text: "Buy 0.25 SOL", callback_data: "amount:0.25" }
      ],
      [
        { text: "TP +25%", callback_data: "tp:25" },
        { text: "TP +50%", callback_data: "tp:50" },
        { text: "TP +100%", callback_data: "tp:100" }
      ],
      [
        { text: "SL -10%", callback_data: "sl:10" },
        { text: "SL -20%", callback_data: "sl:20" },
        { text: "SL -30%", callback_data: "sl:30" }
      ],
      [
        { text: user.trailingStop ? "Trailing: ON" : "Trailing: OFF", callback_data: "trailing:toggle" },
        { text: user.paused ? "▶ Resume entries" : "⏸ Pause entries", callback_data: "pause:toggle" }
      ]
    ]
  };
}
function ensureUserFromCallback(q) {
  return getOrCreateUser(q.message.chat.id, q.from.id);
}

bot.onText(/^\/start(?:@\w+)?$/, async msg => {
  if (!isAllowed(msg)) return bot.sendMessage(msg.chat.id, "Access not permitted.");
  getOrCreateUser(msg.chat.id, msg.from.id);
  await bot.sendMessage(msg.chat.id,
    "🌑 <b>MOON IS WAITING</b>\n\nConnected to Telegram. The live token feed and alert system will run when the worker is online.\n\nThis version uses real launch events but Paper Trading only. No real swaps are implemented.",
    { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⚙️ Configure settings", callback_data: "settings" }]] } });
});
bot.onText(/^\/help(?:@\w+)?$/, msg => bot.sendMessage(msg.chat.id,
  "/start — register and start\n/status — worker status\n/scan — recent tokens in memory\n/positions — open paper positions\n/settings — configure paper trading\n/pause — pause new paper entries\n/resume — resume new paper entries"));
bot.onText(/^\/status(?:@\w+)?$/, msg => {
  const s = getState();
  const user = s.users[String(msg.chat.id)];
  bot.sendMessage(msg.chat.id, `🛰 <b>Worker status</b>\nFeed: <b>${feedConnected ? "CONNECTED" : "DISCONNECTED"}</b>\nTokens seen: <b>${Object.keys(s.tokens).length}</b>\nMode: <b>${user?.mode || "not configured"}</b>\nExecution: <b>PAPER ONLY</b>\nScoring: <b>NOT VALIDATED</b>`, { parse_mode: "HTML" });
});
bot.onText(/^\/settings(?:@\w+)?$/, msg => {
  const user = getOrCreateUser(msg.chat.id, msg.from.id);
  bot.sendMessage(msg.chat.id, settingsText(user), { parse_mode: "HTML", reply_markup: settingsKeyboard(user) });
});
bot.onText(/^\/pause(?:@\w+)?$/, msg => {
  const user = getOrCreateUser(msg.chat.id, msg.from.id);
  updateUser(msg.chat.id, { paused: true });
  bot.sendMessage(msg.chat.id, "⏸ New simulated entries paused. Alerts continue.");
});
bot.onText(/^\/resume(?:@\w+)?$/, msg => {
  const user = getOrCreateUser(msg.chat.id, msg.from.id);
  updateUser(msg.chat.id, { paused: false });
  bot.sendMessage(msg.chat.id, "▶ New simulated entries resumed. Alerts continue.");
});
bot.onText(/^\/positions(?:@\w+)?$/, msg => {
  const positions = userPositions(msg.chat.id);
  if (!positions.length) return bot.sendMessage(msg.chat.id, "No open paper positions.");
  const text = positions.map(p => `• Token ID ${p.tokenId} — ${p.amountSol} SOL simulated — ${p.status}`).join("\n");
  bot.sendMessage(msg.chat.id, `🧪 <b>Open paper positions</b>\n${text}`, { parse_mode: "HTML" });
});
bot.onText(/^\/scan(?:@\w+)?$/, msg => {
  const tokens = Object.values(getState().tokens).slice(-10).reverse();
  if (!tokens.length) return bot.sendMessage(msg.chat.id, "No tokens received yet. Keep the worker online and try again.");
  bot.sendMessage(msg.chat.id, "🆕 <b>Latest token discoveries</b>\n" + tokens.map(t => `• ${escapeHtml(t.name || "Unknown")} (${escapeHtml(t.symbol || "N/A")}) — <code>${escapeHtml(shortAddr(t.mint))}</code>`).join("\n"), { parse_mode: "HTML" });
});

bot.on("callback_query", async q => {
  try {
    const chatId = q.message?.chat?.id;
    if (!chatId) return bot.answerCallbackQuery(q.id);
    const user = ensureUserFromCallback(q);
    const data = q.data || "";
    if (data === "settings") {
      await bot.answerCallbackQuery(q.id);
      return bot.sendMessage(chatId, settingsText(user), { parse_mode: "HTML", reply_markup: settingsKeyboard(user) });
    }
    if (data.startsWith("mode:")) {
      const mode = data.split(":")[1] === "auto" ? "auto" : "manual";
      updateUser(chatId, { mode });
      await bot.answerCallbackQuery(q.id, { text: `Mode set to ${mode}.` });
      return bot.sendMessage(chatId, settingsText(getState().users[String(chatId)]), { parse_mode: "HTML", reply_markup: settingsKeyboard(getState().users[String(chatId)]) });
    }
    if (data.startsWith("amount:")) {
      const amount = Number(data.split(":")[1]);
      if (![0.05, 0.1, 0.25].includes(amount)) return bot.answerCallbackQuery(q.id, { text: "Invalid amount." });
      updateUser(chatId, { buySol: amount });
      await bot.answerCallbackQuery(q.id, { text: `Paper size: ${amount} SOL` });
      return bot.sendMessage(chatId, settingsText(getState().users[String(chatId)]), { parse_mode: "HTML", reply_markup: settingsKeyboard(getState().users[String(chatId)]) });
    }
    if (data.startsWith("tp:")) {
      updateUser(chatId, { takeProfitPct: Number(data.split(":")[1]) });
      await bot.answerCallbackQuery(q.id, { text: "Take-profit updated." });
      return bot.sendMessage(chatId, settingsText(getState().users[String(chatId)]), { parse_mode: "HTML", reply_markup: settingsKeyboard(getState().users[String(chatId)]) });
    }
    if (data.startsWith("sl:")) {
      updateUser(chatId, { stopLossPct: Number(data.split(":")[1]) });
      await bot.answerCallbackQuery(q.id, { text: "Stop-loss updated." });
      return bot.sendMessage(chatId, settingsText(getState().users[String(chatId)]), { parse_mode: "HTML", reply_markup: settingsKeyboard(getState().users[String(chatId)]) });
    }
    if (data === "trailing:toggle") {
      updateUser(chatId, { trailingStop: !user.trailingStop });
      await bot.answerCallbackQuery(q.id, { text: "Trailing stop updated." });
      return bot.sendMessage(chatId, settingsText(getState().users[String(chatId)]), { parse_mode: "HTML", reply_markup: settingsKeyboard(getState().users[String(chatId)]) });
    }
    if (data === "pause:toggle") {
      updateUser(chatId, { paused: !user.paused });
      await bot.answerCallbackQuery(q.id, { text: user.paused ? "Entries resumed." : "Entries paused." });
      return bot.sendMessage(chatId, settingsText(getState().users[String(chatId)]), { parse_mode: "HTML", reply_markup: settingsKeyboard(getState().users[String(chatId)]) });
    }
    const [action, tokenId] = data.split(":");
    const t = getState().tokens[tokenId];
    if (!t) return bot.answerCallbackQuery(q.id, { text: "Token not found; it may have expired from local state." });
    if (action === "analysis") {
      const result = evaluateToken(t);
      await bot.answerCallbackQuery(q.id);
      return bot.sendMessage(chatId, `🔍 <b>Analysis</b>\nToken: ${escapeHtml(t.name || "Unknown")}\nScore: <b>PENDING</b>\n${result.reasons.map(escapeHtml).join("\n")}`, { parse_mode: "HTML" });
    }
    if (action === "buy") {
      if (user.paused) return bot.answerCallbackQuery(q.id, { text: "New entries are paused." });
      const result = evaluateToken(t);
      if (!result.eligible || result.score === null) {
        await bot.answerCallbackQuery(q.id, { text: "Blocked: scoring/risk engine is not validated. No position opened.", show_alert: true });
        return;
      }
      // Safety guard: unreachable until the scoring engine is deliberately implemented and validated.
      addPaperPosition(chatId, tokenId, user.buySol);
      return bot.answerCallbackQuery(q.id, { text: "Paper position opened; no real transaction sent." });
    }
    if (action === "sell") {
      const closed = closePaperPositions(chatId, tokenId);
      return bot.answerCallbackQuery(q.id, { text: closed.length ? `Closed ${closed.length} simulated position(s).` : "No open paper position for this token." });
    }
    await bot.answerCallbackQuery(q.id);
  } catch (err) {
    console.error("Callback error:", err);
    try { await bot.answerCallbackQuery(q.id, { text: "Action failed; check worker logs." }); } catch {}
  }
});

let feedConnected = false;
let reconnectDelay = 1000;
const socket = io(shrineUrl, {
  transports: ["websocket", "polling"],
  reconnection: true,
  reconnectionDelay: 1000,
  reconnectionDelayMax: 30000,
  timeout: 20000
});
socket.on("connect", () => {
  feedConnected = true;
  reconnectDelay = 1000;
  console.log(`Connected to Shrine feed at ${shrineUrl}`);
  socket.emit("subscribe_new_tokens", { protocols: ["PUMPFUN"] }, ack => {
    if (ack?.error) console.error("Shrine subscription error:", ack);
    else console.log("Subscribed to PUMPFUN new-token feed.");
  });
});
socket.on("disconnect", reason => {
  feedConnected = false;
  console.warn("Shrine feed disconnected:", reason);
});
socket.on("connect_error", err => {
  feedConnected = false;
  console.warn("Shrine connection error:", err.message);
});
socket.on("new_token", async event => {
  try {
    if (!event?.mint || event.protocol !== "PUMPFUN") return;
    if (getState().seenMints[event.mint]) return;
    const rawMeta = await fetchMetadata(event.mint);
    const meta = extractMeta(rawMeta);
    const t = registerToken({
      protocol: event.protocol,
      mint: event.mint,
      pool: event.pool || "",
      name: event.name || rawMeta?.name || "",
      symbol: event.symbol || rawMeta?.symbol || "",
      creator: event.creator || rawMeta?.creator || "",
      uri: event.uri || rawMeta?.uri || "",
      timestamp: event.timestamp || Math.floor(Date.now() / 1000),
      image: meta.image,
      description: meta.description,
      website: meta.website,
      twitter: meta.twitter,
      telegram: meta.telegram
    });
    if (!t) return;
    console.log(`New token: ${t.name || "Unknown"} (${t.symbol || "N/A"}) ${t.mint}`);
    for (const user of Object.values(getState().users)) {
      await sendTokenToChat(user.chatId, t);
      // Auto mode is deliberately non-executing while score/risk engine is unvalidated.
      if (user.mode === "auto" && !user.paused) {
        await bot.sendMessage(user.chatId, `🤖 Auto mode is enabled, but this token was NOT bought: the score/risk engine is not validated yet.\nMint: ${t.mint}`);
      }
    }
  } catch (err) {
    console.error("Failed to process token event:", err);
  }
});

bot.on("polling_error", err => console.error("Telegram polling error:", err.message));
bot.on("error", err => console.error("Telegram bot error:", err.message));

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
function shutdown() {
  console.log("Shutting down safely...");
  try { socket.disconnect(); } catch {}
  try { bot.stopPolling(); } catch {}
  saveState();
  process.exit(0);
}

console.log("MOON IS WAITING worker started. Paper Trading only; real swaps are not implemented.");
