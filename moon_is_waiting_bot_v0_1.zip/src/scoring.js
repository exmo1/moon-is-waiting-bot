/**
 * Honest initial scoring placeholder.
 * A reliable 0–100 Alpha Score requires live trade/holder/liquidity data.
 * Do not invent a score from token name or metadata alone.
 */
export function evaluateToken(token) {
  const checks = [];
  if (!token.mint) checks.push("Missing mint address");
  if (!token.name || !token.symbol) checks.push("Name/symbol metadata incomplete");
  if (!token.creator) checks.push("Creator data unavailable");
  if (!token.uri) checks.push("Metadata URI unavailable");
  return {
    score: null,
    scoreLabel: "PENDING",
    eligible: false,
    checks,
    reasons: [
      "Live trade metrics, holder concentration and liquidity checks are not implemented yet.",
      "Automatic entries are blocked until the risk engine is validated."
    ]
  };
}
