# MOON IS WAITING — Telegram discovery bot (v0.1)

This starter connects a Telegram bot to Shrine Trade's free Pump.fun new-token feed and sends token alerts. It is **paper-only**. It does not contain wallet keys, swap code, or the ability to submit blockchain transactions.

## Requirements
- Node.js 20 or newer
- A Telegram bot token from @BotFather
- Internet access

## Setup
1. Extract the ZIP.
2. In this folder, copy `.env.example` to `.env`.
3. Put your Telegram bot token in `.env` as `TELEGRAM_BOT_TOKEN=...`. Do not send the token to anyone or commit `.env` to Git.
4. Install dependencies:
   ```bash
   npm install
   ```
5. Validate syntax:
   ```bash
   npm run check
   ```
6. Start the worker:
   ```bash
   npm start
   ```
7. Open your Telegram bot and send `/start`. The bot only sends alerts to chats that have started it.
8. Use `/status`, `/scan`, `/settings`, `/positions`, `/pause`, and `/resume`.

## What v0.1 does
- Subscribes to Shrine's `subscribe_new_tokens` feed for `PUMPFUN`.
- Deduplicates token mint addresses in a local JSON state file.
- Looks up metadata at `https://sol.shrine.trade/metadata?mint=...`.
- Sends token alerts with image when metadata includes a usable image URL.
- Provides inline buttons for paper-buy, paper-sell, analysis, Solscan and settings.
- Saves user settings and simulated positions in `data/state.json`.

## Important limitations
- The Alpha Score is intentionally `PENDING`; this version does not yet ingest trade velocity, unique buyers, liquidity, holder concentration, creator history or wallet quality. It does not fabricate a score.
- Because the score/risk engine is not validated, paper BUY actions and automatic entries are blocked. The manual/auto setting is a UI preference only at this stage.
- Take-profit, stop-loss and trailing-stop values are stored but cannot trigger exits until price/trade monitoring and position valuation are implemented.
- No real swaps are implemented. Do not add a wallet private key to this project.
- The local JSON state is appropriate for a single worker process, not a multi-instance deployment. Back it up and protect access to the server.
- A free host may sleep or stop the process. Continuous monitoring requires an always-on process; free VM capacity is not guaranteed.

## Troubleshooting
- `Missing TELEGRAM_BOT_TOKEN`: create `.env` from `.env.example` and fill it in.
- Bot doesn't send messages: send `/start` to the bot first.
- `Feed: DISCONNECTED`: inspect the worker logs and internet access.
- Metadata image missing: some tokens have no valid image or the metadata has not arrived yet.

## Security
Never commit `.env`, never paste the Telegram token into chat, and rotate the token via @BotFather immediately if it is exposed.
